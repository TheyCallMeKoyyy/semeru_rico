var callbackInterface = {
    systemName:"Browser",
    setPreference:null,
    getPreference:null,
    getTokenFCM:null,
    getDeviceID:null,
    isInternetAvailable:null,
    goBack:null,
    otherLink:null,
    openLink:null,
    infoUser:""
}; 

//Callback Wrapper
function appCallback(name, data = null){
        switch(name) {
            case "getInfoUser":
                callbackInterface.infoUser = data;
                break;
            case "setSystemName":
                callbackInterface.systemName = data;
                break;
            default:
                break;
        }     
}




// Interface function
var interface = {
    back: function(url=null){
        try{
            back.postMessage('send back');
        }catch(e){
            try{
                backFlutterWebview.postMessage('back');
            }catch(e){
                window.location.href = url;
            }
        }
    },
    openWebview: function(url) {
      openWebview.postMessage(url);
    },
    openWebviewPost: function(data) {
      openWebviewPost.postMessage(data);
    },
    logout(){
        logout.postMessage('logout');
    },
    getInfoUser: function(){
        return new Promise((resolve, reject) => {
            try{
                getInfoUser.postMessage('get info user');    
                setTimeout(() => {
                    resolve(callbackInterface.infoUser);
                }, 300);
            }catch(e){
                reject(null);
            }
        });
    }
};